<?php $__env->startSection('title'); ?>
Halaman Buat Soal Psikotest
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Soal Psikotest
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Masukan jumlah soal yang akan ditambah ke Psikotest <?php echo e($kode_soal); ?>:</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
          <form action="<?php echo e(url('/buat_soal_psikotest_with_code')); ?>" role="form" method="POST">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <input type="hidden" name="kode" value="<?php echo e($kode_soal); ?>">
                <input type="number" min="1" class="form-control" name="jumlah" placeholder="Jumlah Soal" style="width: 230px;" required="required">
              </div>
              <div class="box-footer">
                <button name="submit" value="submit" type="submit" class="btn btn-primary">Next</button>
              </div>
            </form>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_tim_ppdb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>