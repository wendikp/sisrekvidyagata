<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(url('/image/logo_sekolah.jpg')); ?>">
  <title>SisRek Vidyagata | <?php echo $__env->yieldContent('title'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/Ionicons/css/ionicons.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/dist/css/AdminLTE.min.css')); ?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
  folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/dist/css/skins/_all-skins.min.css')); ?>">
  <!-- CSS lainnya -->
  <?php echo $__env->yieldContent('style'); ?>

  <!-- Scripts -->
  <!-- <script src="<?php echo e(asset('js/app.js')); ?>" defer></script> -->

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <!-- Modal CSS -->
  <?php echo $__env->yieldContent('modal-css'); ?>
</head>
<body class="hold-transition skin-green sidebar-mini">
  <div class="wrapper">

    <header class="main-header">

      <!-- Logo -->
      <a href="<?php echo e(asset('AdminLTE/index2.html')); ?>" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini">SrV</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>SisRek</b> Vidyagata</span>
      </a>

      <!-- Header Navbar: style can be found in header.less -->
      <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
          <span class="sr-only">Toggle navigation</span>
        </a>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <!-- User Account: style can be found in dropdown.less -->
            <li class="dropdown user user-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <?php echo e(Auth::user()->name); ?><span class="caret"></span>
              </a>
              <ul class="dropdown-menu" style="width: 50px">
                <!-- Menu Body -->
                <li class="user-body">
                  <div class="row">
                    <!-- <div class="col-xs-4 text-center"> -->
                    <div class="text-center">
                      <a href="<?php echo e(route('logout')); ?>" 
                      onclick="event.preventDefault();
                      document.getElementById('logout-form').submit();">
                      <?php echo e(__('Logout')); ?>

                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                      <?php echo csrf_field(); ?>
                    </form>
                  </div>
                </div>
                <!-- /.row -->
              </li>
            </ul>
          </li>
        </ul>
      </div>

    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('AdminLTE/dist/img/user.jpg')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(Auth::user()->name); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MENU UTAMA</li>
        <li><a href="<?php echo e(url('/dashboard-tim-ppdb')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-file-text-o"></i> <span>Kriteria Peminatan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href=" <?php echo e(url('/daftar_kriteria_peminatan')); ?> "><i class="fa fa-genderless"></i> Daftar Kriteria Peminatan</a></li>
            <li><a href=" <?php echo e(url('/angket_peminatan/angkatan_siswa')); ?> "><i class="fa fa-genderless"></i> Angket Peminatan Siswa</a></li>
          </ul>
        </li>
        <li><a href="<?php echo e(url('/daftar_rombel')); ?>"><i class="fa fa-book"></i> Daftar Rombel</a></li>
        <!-- <li><a href="<?php echo e(url('/daftar_psikotest')); ?>"><i class="fa fa-file-text"></i> Daftar Psikotest</a></li> -->
        <li><a href="<?php echo e(url('/daftar_pengumuman')); ?>"><i class="fa fa-bullhorn"></i> Pengumuman</a></li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-trash"></i> <span>Trash</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href=" <?php echo e(url('daftar_kriteria_peminatan_deleted')); ?> "><i class="fa fa-genderless"></i> Daftar Kriteria Peminatan</a></li>
            <!-- <li><a href=" <?php echo e(url('deleted_psikotest')); ?> "><i class="fa fa-genderless"></i> Psikotest</a></li> -->
            <li><a href=" <?php echo e(url('deleted_pengumuman')); ?> "><i class="fa fa-genderless"></i> Pengumuman</a></li>
          </ul>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <?php echo $__env->yieldContent('content'); ?>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2018 <a href="https://vidyagata.wordpress.com/about/">SMAN 6 Malang</a>.</strong> All rights
    reserved.
  </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo e(asset('AdminLTE/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('AdminLTE/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo e(asset('AdminLTE/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('AdminLTE/bower_components/fastclick/lib/fastclick.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('AdminLTE/dist/js/adminlte.min.js')); ?>"></script>
<!-- Script.js lainnya -->
<?php echo $__env->yieldContent('script-js'); ?>
<!-- Page script lainnya -->
<?php echo $__env->yieldContent('page-script'); ?>

</body>
</html>
