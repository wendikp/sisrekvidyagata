<?php $__env->startSection('title'); ?>
Halaman Tambah Rombel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Tambah Rombel
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Form. Tambah Rombel IPS</h3>
          </div><!-- /.box-header -->
          <div class="box-body table-responsive">
            <form action="<?php echo e(url('/store_rombel')); ?>" role="form" method="POST">
              <?php echo csrf_field(); ?>
              <table id="example2" class="table table-hover">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Nama Rombel</th>
                    <th>Wali Kelas</th>
                    <th>Kuota Kelas</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  for ($i=0; $i<$jumlah; $i++) { 
                    ?>
                    <tr>
                      <td><?php echo ($i+1) ?></td>
                      <td>
                        <div class="form-group">
                          <input type="hidden" name="peminatan" value="ips">
                          <input type="text" class="form-control" name="nama_rombel[]" placeholder="Nama Rombel" required="required">
                        </div>
                      </td>
                      <td>
                        <div class="form-group">
                          <input type="text" class="form-control" name="wali_kelas[]" placeholder="Wali Kelas" required="required">
                        </div>
                      </td>
                      <td>
                        <div class="form-group">
                          <input type="text" class="form-control" name="kuota_kelas[]" placeholder="Kuota kelas" required="required">
                        </div>
                      </td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
                <div class="box-footer">
                  <button name="submit" value="submit" type="submit" class="btn btn-primary pull-right">Submit</button>
                </div>
              </form>
            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_waka_kurikulum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>