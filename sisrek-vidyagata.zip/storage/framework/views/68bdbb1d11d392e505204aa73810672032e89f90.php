<?php $__env->startSection('title'); ?>
Halaman Edit Angket Peminatan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Daftar Angket Peminatan
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/dashboard-tim-ppdb')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li><a href="<?php echo e(url('/angket_peminatan/angkatan_siswa')); ?>">Angkatan Siswa</a></li>
      <li><a href="<?php echo e(url('/angket_peminatan/angkatan_siswa/angket/'.$angkatan)); ?>">Daftar Angket Peminatan <?php echo e($angkatan); ?></a></li>
      <li class="active">Edit</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Angket Peminatan Siswa Baru : <?php echo e($nama); ?></h3>
          </div><!-- /.box-header -->
          <div class="box-body table-responsive">
            <form action="<?php echo e(url('/angket_peminatan/angkatan_siswa/angket/edit/update/'.$id_user)); ?>" role="form" method="POST">
              <?php echo csrf_field(); ?>
              <table id="example2" class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th>Kriteria</th>
                    <th>Nilai</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data_angket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($data->kriteria); ?></td>
                    <td>
                    <?php if($data->kategori == 1): ?>
                      <input type="hidden" name="id_kriteria[] " value="<?php echo e($data->id); ?>">
                      <input type="text" class="form-control" name="nilai[]" value="<?php echo e($data->nilai); ?>">
                    <?php elseif($data->kategori == 2): ?>
                      <input type="hidden" name="id_kriteria[] " value="<?php echo e($data->id); ?>">
                      <input type="text" class="form-control" name="nilai[]" value="<?php echo e($data->nilai); ?>" readonly>
                    <?php else: ?>
                      <input type="hidden" name="id_kriteria[] " value="<?php echo e($data->id); ?>">
                      <select class="form-control" name="nilai[]" required="required">
                        <?php if($data->nilai == "Sangat minat"): ?>
                        <option value="Sangat minat">Sangat minat</option>
                        <option value="Minat">Minat</option>
                        <option value="Cukup">Cukup</option>
                        <option value="Kurang minat">Kurang minat</option>
                        <option value="Tidak minat">Tidak minat</option>
                        <?php elseif($data->nilai == "Minat"): ?>
                        <option value="Minat">Minat</option>
                        <option value="Sangat minat">Sangat minat</option>
                        <option value="Cukup">Cukup</option>
                        <option value="Kurang minat">Kurang minat</option>
                        <option value="Tidak minat">Tidak minat</option>
                        <?php elseif($data->nilai == "Cukup"): ?>
                        <option value="Cukup">Cukup</option>
                        <option value="Sangat minat">Sangat minat</option>
                        <option value="Minat">Minat</option>
                        <option value="Kurang minat">Kurang minat</option>
                        <option value="Tidak minat">Tidak minat</option>
                        <?php elseif($data->nilai == "Kurang minat"): ?>
                        <option value="Kurang minat">Kurang minat</option>
                        <option value="Sangat minat">Sangat minat</option>
                        <option value="Minat">Minat</option>
                        <option value="Cukup">Cukup</option>
                        <option value="Tidak minat">Tidak minat</option>
                        <?php elseif($data->nilai == "Tidak minat"): ?>
                        <option value="Tidak minat">Tidak minat</option>
                        <option value="Sangat minat">Sangat minat</option>
                        <option value="Minat">Minat</option>
                        <option value="Cukup">Cukup</option>
                        <option value="Kurang minat">Kurang minat</option>
                        <?php endif; ?>
                      </select>
                    <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <div class="box-footer">
                <button name="submit" value="submit" type="submit" class="btn btn-primary pull-right">Submit</button>
              </div>
            </form>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_tim_ppdb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>