<?php $__env->startSection('title'); ?>
Halaman Tambah Pengguna
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Tambah Pengguna
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Form. Tambah Siswa Baru</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
            <form action="" role="form" method="POST">
              <div class="form-group">
                <label for="">Nama Lengkap</label>
                <input type="text" class="form-control" name="nama_lkp" placeholder="Nama Lengkap" style="width: 230px;" required="required">
              </div>
              <div class="form-group">
                <label for="">NIS/NISN</label>
                <input type="text" class="form-control" name="nisn" placeholder="NIS/NISN" style="width: 230px;" required="required">
              </div>
              <div class="form-group">
                <label for="">Asal Sekolah</label>
                <input type="text" class="form-control" name="asal_sklh" placeholder="Asal Sekolah" style="width: 230px;" required="required">
              </div>
              <div class="form-group">
                <label for="">Tanggal Lahir</label>
                <input type="text" class="form-control tanggal" id="tgl_lhr" name="tgl_lhr" placeholder="Tanggal Lahir" style="width: 230px;" required="required">
              </div>
              <div class="form-group">
                <label for="nopol">Alamat</label>
                <textarea class="form-control " name="alamat" rows="5" cols="80" style="width: 500px;"></textarea>
              </div>
              <div class="box-footer">
                <button name="submit" value="submit" type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>