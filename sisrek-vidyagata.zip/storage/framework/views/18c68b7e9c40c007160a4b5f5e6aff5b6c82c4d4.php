<?php $__env->startSection('title'); ?>
Halaman Soal Psikotest
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Psikotest
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">
              Daftar Soal Psikotest (Deleted)
            </h3>
          </div><!-- /.box-header -->
          <div class="box-body table-responsive">
            <table id="example2" class="table table-striped">
              <tbody>
                <thead>
                  <th>No.</th>
                  <th>Kode Psikotest</th>
                  <th>Tanggal dibuat</th>
                  <th>Soal</th>
                  <th>Gambar</th>
                  <th>Jawaban</th>
                  <th>Tools</th>
                </thead>
                <?php 
                $i=0;
                foreach ($data_soal as $data){
                  ?>
                  <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($data->psikotest_code); ?></td>
                    <td><?php echo e($data->day); ?>-<?php echo e($data->month); ?>-<?php echo e($data->year); ?></td>
                    <td><?php echo e($data->soal); ?></td>
                    <?php
                    if ($data->gambar != NULL) {
                      ?>
                      <td><?php echo e($data->gambar); ?></td>
                      <?php
                    } else {
                      ?>
                      <td>Tidak ada gambar</td>
                      <?php
                    }

                    if ($data->jawaban == 'a') {
                      ?>
                      <td>A.<?php echo e($data->a); ?></td>
                      <?php
                    } elseif ($data->jawaban == 'b') {
                      ?>
                      <td>B.<?php echo e($data->b); ?></td>
                      <?php
                    } elseif ($data->jawaban == 'c') {
                      ?>
                      <td>C.<?php echo e($data->c); ?></td>
                      <?php
                    } elseif ($data->jawaban == 'd') {
                      ?>
                      <td>D.<?php echo e($data->d); ?></td>
                      <?php
                    } else {
                      ?>
                      <td>E.<?php echo e($data->e); ?></td>
                      <?php
                    }
                    ?>
                    <td>
                      <div class="btn-group">
                        <a href="<?php echo e(url('/restore_soal_psikotest/'.$data->id)); ?>" class="btn btn-default"><i class="fa fa-undo"></i></a>
                      </div>
                    </td>
                  </tr>   
                  <?php 
                }

                if (count($data_soal) <= 0) {
                  ?>
                  <tr>
                    <td colspan="7" align="center">Belum Ada Data</td>
                  </tr>
                  <?php
                }
                ?>
              </tbody>
            </table>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_tim_ppdb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>