<?php $__env->startSection('title'); ?>
Halaman Tambah Kriteria Peminatan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Bobot Kriteria Peminatan
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/dashboard-waka-kurikulum')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li><a href="<?php echo e(url('/daftar_kriteria_peminatan')); ?>">Daftar Kriteria Peminatan</a></li>
      <li class="active">Tentukan Bobot Kriteria</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title"><b>Form. Pengisian Bobot Kriteria Jurusan IPA</b></h3>
          </div><!-- /.box-header -->
          <div class="box-body table-responsive">
            <form action="<?php echo e(url('/daftar_kriteria/CI_CR/'.$id)); ?>" role="form" method="POST">
              <?php echo csrf_field(); ?>
              <table id="example2" class="table table-hover table-bordered">
                <?php
                // thead-atas
                for ($i=0; $i < 1; $i++) { 
                  ?>
                  <tbody>
                    <thead>
                      <tr>
                        <th>Kriteria/Kriteria</th>
                        <?php 
                        // $j=0;
                        foreach ($data_kriteria as $data) {
                          ?>
                          <th><?php echo e($data->kriteria); ?></th>
                          <?php
                          // $j++;
                        }
                        ?>
                      </tr>
                    </thead>
                    <?php
                  } 
                  // /.thead-atas

                  $i=0;
                  // bagian thead samping dan inputan bobot
                  foreach ($data_kriteria as $data) {
                    ?>
                    <tr>
                      <th><?php echo e($data->kriteria); ?></th>
                      
                      <?php
                      for ($j=0; $j < count($data_kriteria); $j++) { 
                        if ($i==$j) {
                          ?>
                          <td>
                            <input type="text" name="bobot_ipa[<?php echo e($i); ?>][<?php echo e($j); ?>]" value="1" style="width: 50px" readonly>
                          </td>
                          <?php
                        } else {
                          ?>
                          <td>
                            <input type="text" name="bobot_ipa[<?php echo e($i); ?>][<?php echo e($j); ?>]" placeholder="bobot" style="width: 50px" required="required">
                          </td>
                          <?php
                        }
                      }
                      ?>
                    </tr>
                    <?php
                    $i++;
                  }
                  // /.bagian thead samping dan inputan bobot
                  ?>
                </tbody>
              </table>
              <hr>
              <!-- tabel ips -->
              <div class="box-header with-border">
              <h3 class="box-title"><b>Form. Pengisian Bobot Kriteria Jurusan IPS</b></h3>
              </div><!-- /.box-header -->
              <table id="example2" class="table table-hover table-bordered">
                <?php
                for ($i=0; $i < 1; $i++) { 
                  ?>
                  <tbody>
                    <thead>
                      <tr>
                        <th>Kriteria/Kriteria</th>
                        <?php 
                        $j=0;
                        foreach ($data_kriteria as $data) {
                          ?>
                          <th><?php echo e($data->kriteria); ?></th>
                          <?php
                          $j++;
                        }
                        ?>
                      </tr>
                    </thead>
                    <?php
                  } 

                  $i=0;
                  foreach ($data_kriteria as $data) {
                    ?>
                    <tr>
                      <th><?php echo e($data->kriteria); ?></th>
                      
                      <?php
                      for ($j=0; $j < count($data_kriteria); $j++) { 
                        if ($i==$j) {
                          ?>
                          <td>
                            <input type="text" name="bobot_ips[<?php echo e($i); ?>][<?php echo e($j); ?>]" value="1" style="width: 50px" readonly>
                          </td>
                          <?php
                        } else {
                          ?>
                          <td>
                            <input type="text" name="bobot_ips[<?php echo e($i); ?>][<?php echo e($j); ?>]" placeholder="bobot" style="width: 50px" required="required">
                          </td>
                          <?php
                        }
                      }
                      ?>
                    </tr>
                    <?php
                    $i++;
                  }
                  ?>
                </tbody>
              </table>
              <hr>
              <!-- tabel bahasa -->
              <div class="box-header with-border">
              <h3 class="box-title"><b>Form. Pengisian Bobot Kriteria Jurusan Bahasa</b></h3>
              </div><!-- /.box-header -->
              <table id="example2" class="table table-hover table-bordered">
                <?php
                for ($i=0; $i < 1; $i++) { 
                  ?>
                  <tbody>
                    <thead>
                      <tr>
                        <th>Kriteria/Kriteria</th>
                        <?php 
                        $j=0;
                        foreach ($data_kriteria as $data) {
                          ?>
                          <th><?php echo e($data->kriteria); ?></th>
                          <?php
                          $j++;
                        }
                        ?>
                      </tr>
                    </thead>
                    <?php
                  } 

                  $i=0;
                  foreach ($data_kriteria as $data) {
                    ?>
                    <tr>
                      <th><?php echo e($data->kriteria); ?></th>
                      
                      <?php
                      for ($j=0; $j < count($data_kriteria); $j++) { 
                        if ($i==$j) {
                          ?>
                          <td>
                            <input type="text" name="bobot_bhs[<?php echo e($i); ?>][<?php echo e($j); ?>]" value="1" style="width: 50px" readonly>
                          </td>
                          <?php
                        } else {
                          ?>
                          <td>
                            <input type="text" name="bobot_bhs[<?php echo e($i); ?>][<?php echo e($j); ?>]" placeholder="bobot" style="width: 50px" required="required">
                          </td>
                          <?php
                        }
                      }
                      ?>
                    </tr>
                    <?php
                    $i++;
                  }
                  ?>
                </tbody>
              </table>
              <div class="box-footer">
                <button name="submit" value="submit" type="submit" class="btn btn-primary pull-right">Submit</button>
              </div>
            </form>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_waka_kurikulum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>