<?php $__env->startSection('title'); ?>
Halaman Rekomendasi Peminatan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper layout-boxed">
  <div class="container">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Rekomendasi Peminatan Siswa
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-6">
          <div class="box box-solid">
            <div class="box-header with-border">
              <i class="fa fa-info-circle"></i>

              <h3 class="box-title">Informasi Peminatan Siswa</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <dl class="dl-horizontal">
              <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <dt>Nomor Induk Siswa</dt>
                <dd><?php echo e($data->no_induk); ?></dd>
                <dt>Nama</dt>
                <dd><?php echo e($data->name); ?></dd>
                <dt>Rombongan Belajar</dt>
                <dd>X - <?php echo e($data->nama_rombel); ?></dd>
                <dt>Wali Kelas</dt>
                <dd><?php echo e($data->wali_kelas); ?></dd>
                <dt>Peminatan</dt>
                <dd><?php echo e($data->peminatan); ?></dd>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if(count($data_siswa) == 0): ?>
              <p>Peminatan belum ditentukan.</p>
              <?php endif; ?>
              </dl>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- ./col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
  </div>
  <!-- /.container -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_siswa', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>