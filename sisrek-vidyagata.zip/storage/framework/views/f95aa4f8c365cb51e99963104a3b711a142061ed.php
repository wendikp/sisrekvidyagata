<?php $__env->startSection('title'); ?>
Halaman Daftar Pengumuman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper layout-boxed">
  <div class="container">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Pengumuman
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Daftar Pengumuman</h3>
          </div><!-- /.box-header -->
          <div class="box-body table-responsive">
            <table id="example2" class="table table-striped">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Judul</th>
                  <th>Tanggal Pembuatan</th>
                </tr>
              </thead>
              <tbody>
                <?php $i=1; ?>
                <?php $__currentLoopData = $data_pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo ($i++) ?></td>
                  <td><a href="<?php echo e(url('/detail-pengumuman/'.$data->id)); ?>"><?php echo e($data->judul); ?></a></td>
                  <td><?php echo e($data->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php 
                if (count($data_pengumuman) <= 0) {
                  ?>
                  <tr>
                    <td colspan="3" align="center">Belum Ada Pengumuman</td>
                  </tr>
                  <?php
                }
                ?>
              </tbody>
            </table>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
  </div>
  <!-- /.container -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_siswa', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>