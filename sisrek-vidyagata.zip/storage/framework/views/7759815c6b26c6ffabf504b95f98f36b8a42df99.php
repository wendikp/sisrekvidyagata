<?php $__env->startSection('title'); ?>
Halaman Edit Rombel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit Rombel
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Form. Edit Rombel</h3>
          </div><!-- /.box-header -->
          <div class="box-body table-responsive">
            <form action="<?php echo e(url('/tahun_ajaran/daftar_rombel/update')); ?>" role="form" method="POST">
              <?php echo csrf_field(); ?>
              <table id="example2" class="table table-hover">
                <thead>
                  <tr>
                    <th>Nama Rombel</th>
                    <th>Wali Kelas</th>
                    <th>Kuota Kelas</th>
                    <th>Tahun Ajaran</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data_rombel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      <div class="form-group">
                      <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                      <input type="hidden" name="peminatan" value="<?php echo e($data->peminatan); ?>">
                        <input type="text" class="form-control" name="nama_rombel" value="<?php echo e($data->nama_rombel); ?>" required="required">
                      </div>
                    </td>
                    <td>
                      <div class="form-group">
                        <input type="text" class="form-control" name="wali_kelas" value="<?php echo e($data->wali_kelas); ?>" required="required">
                      </div>
                    </td>
                    <td>
                      <div class="form-group">
                        <input type="text" class="form-control" name="kuota_kelas" value="<?php echo e($data->kuota_kelas); ?>" required="required">
                      </div>
                    </td>
                    <td>
                      <div class="form-group">
                        <input type="text" class="form-control" name="tahun_ajaran" value="<?php echo e($data->tahun_ajar); ?>" required="required" data-inputmask='"mask": "9999"' data-mask placeholder="Ex: 2019">
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <div class="box-footer">
                <button name="submit" value="submit" type="submit" class="btn btn-primary pull-right">Submit</button>
              </div>
            </form>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<!-- InputMask -->
<script src="<?php echo e(asset('AdminLTE/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('AdminLTE/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('AdminLTE/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script type="text/javascript">
  //Input mask
  $('[data-mask]').inputmask()
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_waka_kurikulum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>