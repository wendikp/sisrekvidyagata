<?php $__env->startSection('title'); ?>
Halaman Angket Peminatan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper layout-boxed">
  <div class="container">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Angket Peminatan Siswa
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
      <div class="col-xs-12">
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Angket Peminatan Siswa Baru SMAN 6 Malang</h3>
              <a href="<?php echo e(url('/edit-angket-peminatan/'.Auth::user()->id)); ?>" class="btn btn-default pull-right"><i class="fa fa-edit"></i> Edit</a>
            </div><!-- /.box-header -->
            <div class="box-body table-responsive">
              <table id="example2" class="table table-striped">
                <thead>
                  <tr>
                    <th>Kriteria</th>
                    <th>Nilai</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data_angket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($data->kriteria); ?></td>
                    <td><?php echo e($data->nilai); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <!-- /.content -->
  </div>
  <!-- /.container -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_siswa', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>