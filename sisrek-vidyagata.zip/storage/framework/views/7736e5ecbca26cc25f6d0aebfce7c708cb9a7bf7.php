<?php $__env->startSection('title'); ?>
Halaman Edit Pengguna
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit Pengguna
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Form. Edit Anggota Tim PPDB</h3>
          </div><!-- /.box-header -->
          <div class="box-body  table-responsive">
            <form action="<?php echo e(url('/update_tim_ppdb')); ?>" role="form" method="POST">
              <?php echo csrf_field(); ?>
              <?php $__currentLoopData = $data_tim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
              <table class="table table-responsive table-condensed">
                <tr>
                  <div class="form-group">
                    <td style="border: none; width: 110px;">NIP/NIK</td>
                    <td style="border: none; width: 20px;">:</td>
                    <td style="border: none;"><input type="text" class="form-control" name="no_induk" value="<?php echo e($data->no_induk); ?>" style="width: 230px;" required="required"></td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">Nama Lengkap</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;"><input type="text" class="form-control" name="nama" value="<?php echo e($data->name); ?>" style="width: 230px;" required="required"></td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">Email</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;"><input type="email" class="form-control" name="email" value="<?php echo e($data->email); ?>" style="width: 230px;" required="required"></td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">No. HP</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;">
                      <input type="text" class="form-control" name="no_hp" value="<?php echo e($data->no_telepon); ?>" style="width: 230px;" required="required" data-inputmask='"mask": "9999-9999-9999"' data-mask>
                    </td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">Tanggal Lahir</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;">
                      <div class="input-group date">
                        <div class="input-group-addon">
                          <i class="fa fa-calendar"></i>
                        </div>
                        <?php
                        $exploded_data = explode("-", $data->tgl_lahir);
                        ?>
                        <input type="text" class="form-control" id="datepicker" name="tgl_lahir" value='<?php echo "$exploded_data[2]-$exploded_data[1]-$exploded_data[0]" ?>' style="width: 192px;" required="required">
                      </div>
                    </td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">Jenis Kelamin</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;">
                      <select name="jenis_kelamin" class="form-control" style="width: 130px;" required="required">
                        <?php
                        if ($data->jenis_kelamin == "L" || $data->jenis_kelamin == "Laki-laki") {
                          ?>
                          <option value="L">Laki-laki</option>
                          <?php
                        } else {
                          ?>
                          <option value="P">Perempuan</option>
                          <?php
                        }
                        ?>
                      </select>
                    </td>
                  </div>
                </tr>
                <tr>
                  <td style="border: none;">Periode</td>
                  <td style="border: none;">:</td>
                  <td style="border: none;">
                    <input type="text" class="form-control" name="periode" value="<?php echo e($data->periode); ?>" style="width: 230px;" required="required" data-inputmask='"mask": "9999 - 9999"' data-mask placeholder="Ex: 2010 - 2014">
                  </td>
                </tr>
                <tr>
                  <td style="border: none;">Alamat</td>
                  <td style="border: none;">:</td>
                  <td style="border: none;"><textarea class="form-control " name="alamat" rows="3" cols="80" required="required"><?php echo e($data->alamat); ?></textarea></td>
                </tr>
              </table>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="box-footer">
              <button name="submit" value="submit" type="submit" class="btn btn-primary pull-right">Submit</button>
            </div>
          </form>
        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </div><!-- /.col -->
  </div><!-- /.row -->
</section><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>