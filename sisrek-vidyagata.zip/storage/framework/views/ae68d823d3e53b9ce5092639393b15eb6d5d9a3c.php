<?php $__env->startSection('title'); ?>
Halaman Edit Kriteria Peminatan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit Kriteria Peminatan
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Form. Edit Kriteria Peminatan</h3>
          </div><!-- /.box-header -->
          <div class="box-body table-responsive">
          <form action="<?php echo e(url('/update_kriteria')); ?>" role="form" method="POST">
              <?php echo csrf_field(); ?>
              <table id="example2" class="table table-hover">
                <thead>
                  <tr>
                    <th>Kode Kriteria</th>
                    <th>Kriteria</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  foreach ($data_kriteria as $data) {
                    ?>
                    <tr>
                      <td>
                        <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo e($data->id); ?>" >
                          <input type="text" class="form-control" name="kode_kriteria" value="<?php echo e($data->kode_kriteria); ?>" style="width: 50px;" required="required">
                        </div>
                      </td>
                      <td>
                        <div class="form-group">
                          <input type="text" class="form-control" name="kriteria" value="<?php echo e($data->kriteria); ?>" required="required">
                        </div>
                      </td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
                <div class="box-footer">
                  <button name="submit" value="submit" type="submit" class="btn btn-primary pull-right">Submit</button>
                </div>
              </form>
            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_waka_kurikulum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>