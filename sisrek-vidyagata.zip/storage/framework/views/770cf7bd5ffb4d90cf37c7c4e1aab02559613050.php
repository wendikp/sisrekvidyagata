<?php $__env->startSection('title'); ?>
Halaman Daftar Angket Peminatan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Daftar Angket Peminatan
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/dashboard-tim-ppdb')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li><a href="<?php echo e(url('/angket_peminatan/angkatan_siswa')); ?>">Angkatan Siswa</a></li>
      <li class="active">Daftar Angket Peminatan</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Daftar Angket Peminatan Siswa Baru Angkatan <?php echo e($angkatan); ?></h3>
            <div>
            <?php if($tombol_rekomendasi == 'on'): ?>
            <span class="label label-success">Semua siswa telah mengisi angket peminatan</span>
            <?php else: ?>
            <span class="label label-danger">Beberapa siswa belum mengisi angket peminatan</span>
            <?php endif; ?>

            <?php if($status_bobot == 1): ?>
            <span class="label label-success">Bobot preferensi sudah ditentukan</span>
            <?php else: ?>
            <span class="label label-danger">Bobot preferensi belum ditentukan</span>
            <?php endif; ?>
            </div>

            <div class="btn-group pull-right">
            <a href="<?php echo e(url('/angket_peminatan/angkatan_siswa/angket/export_data/'.$angkatan)); ?>" class="btn btn-sm btn-success"><i class="fa fa-file-excel-o"></i> Export Data</a>
            <?php if($tombol_rekomendasi == 'on' && $status_bobot == 1): ?>
            <a href="<?php echo e(url('/angket_peminatan/angkatan_siswa/angket/hasilkan_rekomendasi/'.$angkatan)); ?>" class="btn btn-sm btn-success"> Hasilkan Rekomendasi</a>
            <?php else: ?>
            <a href="#" class="btn btn-sm btn-default disabled"> Hasilkan Rekomendasi</a>
            <?php endif; ?>
            </div>

          </div><!-- /.box-header -->
          <div class="box-body table-responsive">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>No. Induk</th>
                  <th>Nama</th>
                  <?php $__currentLoopData = $header_kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th><?php echo e($data->kriteria); ?></th>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <th>Tools</th>
                </tr>
              </thead>
              <tbody>
                <?php for($i=0; $i < $baris; $i++): ?>
                <tr>
                  <?php for($j=0; $j < $kolom; $j++): ?>
                  <?php if($j == 0): ?>
                  <td><?php echo e($i+1); ?></td>
                  <?php $j++; ?>
                  <?php endif; ?>
                  <td><?php echo e($angket_peminatan[$i][$j]); ?></td>
                  <?php endfor; ?>
                  <td width="100">
                    <div class="btn-group">
                      <a href="<?php echo e(url('/angket_peminatan/angkatan_siswa/angket/edit/'.$angket_peminatan[$i][0])); ?>" class="btn btn-default" data-toggle="tooltip" title="Edit Angket Siswa"><i class="fa fa-pencil"></i></a>
                    </div>
                  </td>
                </tr>
                <?php endfor; ?>
              </tbody>
            </table>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  });

  $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_tim_ppdb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>