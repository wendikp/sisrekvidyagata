<?php $__env->startSection('title'); ?>
Halaman Soal Psikotest
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">

<style type="text/css">
  .example-modal .modal {
    position: relative;
    top: auto;
    bottom: auto;
    right: auto;
    left: auto;
    display: block;
    z-index: 1;
  }

  .example-modal .modal {
    background: transparent !important;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Psikotest
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/dashboard-tim-ppdb')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li><a href="<?php echo e(url('/daftar_psikotest')); ?>">Daftar Psikotest</a></li>
      <li class="active">Soal</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">
              Soal Psikotest : <?php echo e($kode_soal); ?>

            </h3>
            <button type="button" class="btn btn-default btn-sm pull-right" data-toggle="modal" data-target="#modal-default">
              <i class="fa fa-plus"></i> Buat Soal Baru
            </button>
          </div><!-- /.box-header -->

          <!-- Form modal -->
          <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title">Silahkan masukkan jumlah soal</h4>
                </div>
                <div class="modal-body">
                  <form action="<?php echo e(url('/daftar_psikotest/soal/tambah/'.$kode_soal)); ?>" role="form" method="POST">
                    <?php echo csrf_field(); ?>
                    <table class="table table-responsive">
                      <tr>
                        <td style="border: none; width: 110px;">Jumlah Soal</td>
                        <td style="border: none; width: 10px">:</td>
                        <td style="border: none;">
                          <input type="number" class="form-control" name="jumlah" style="width: 220px;" required="required">
                        </td>
                      </tr>
                    </table>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Tutup</button>
                    <button type="submit" value="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div>
              <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
          </div>
          <!-- /.modal -->

          <div class="box-body table-responsive">
            <table id="example2" class="table table-bordered">
              <tbody>
                <?php 
                $i=0;
                foreach ($data_soal as $data){
                  ?>
                  <tr>
                    <td rowspan="4"><?php echo e(++$i); ?></td>
                    <td colspan="2"><?php echo e($data->soal); ?></td>
                    <?php
                    if ($data->gambar != NULL) {
                      ?>
                      <td colspan="2"><?php echo e($data->gambar); ?></td>
                      <?php
                    }
                    ?>
                    <td rowspan="4" width="100">
                      <div class="btn-group">
                        <a href="<?php echo e(url('/edit_soal_psikotest/'.$data->id)); ?>" class="btn btn-default"><i class="fa fa-edit"></i></a>
                        <a href="<?php echo e(url('/hapus_soal_psikotest/'.$data->id)); ?>" class="btn btn-default"><i class="fa fa-trash"></i></a>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <?php
                    if ($data->jawaban == 'a') {
                      ?>
                      <td style="color: blue"><b>A.<?php echo e($data->a); ?></b></td>
                      <?php
                    } else {
                      ?>
                      <td>A.<?php echo e($data->a); ?></td>
                      <?php
                    }

                    if ($data->jawaban == 'd') {
                      ?>
                      <td style="color: blue"><b>D.<?php echo e($data->d); ?></b></td>
                      <?php
                    } else {
                      ?>
                      <td>D.<?php echo e($data->d); ?></td>
                      <?php
                    }
                    ?>
                  </tr>
                  <tr>
                    <?php
                    if ($data->jawaban == 'b') {
                      ?>
                      <td style="color: blue"><b>B.<?php echo e($data->b); ?></b></td>
                      <?php
                    } else {
                      ?>
                      <td>B.<?php echo e($data->b); ?></td>
                      <?php
                    }
                    
                    if ($data->jawaban == 'e') {
                      ?>
                      <td rowspan="2" style="color: blue"><b>E.<?php echo e($data->e); ?></b></td>
                      <?php
                    } else {
                      ?>
                      <td rowspan="2">E.<?php echo e($data->e); ?></td>
                      <?php
                    }
                    ?>
                  </tr>
                  <tr>
                    <?php
                    if ($data->jawaban == 'c') {
                      ?>
                      <td style="color: blue"><b>C.<?php echo e($data->c); ?></b></td>
                      <?php
                    } else {
                      ?>
                      <td>C.<?php echo e($data->c); ?></td>
                      <?php
                    }
                    ?>
                  </tr>
                  <?php 
                }
                if (count($data_soal) <= 0) {
                  ?>
                  <tr>
                    <td colspan="4" align="center">Belum Ada Data</td>
                  </tr>
                  <?php
                }
                ?>
              </tbody>
            </table>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  });

  $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_tim_ppdb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>