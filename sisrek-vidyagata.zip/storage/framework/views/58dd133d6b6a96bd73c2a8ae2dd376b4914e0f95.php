<?php $__env->startSection('title'); ?>
Halaman Daftar Siswa Rombel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">

<style>
  .example-modal .modal {
    position: relative;
    top: auto;
    bottom: auto;
    right: auto;
    left: auto;
    display: block;
    z-index: 1;
  }

  .example-modal .modal {
    background: transparent !important;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Daftar Siswa Rombel
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/dashboard-tim-ppdb')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li><a href="<?php echo e(url('/daftar_rombel')); ?>">Tahun Ajaran</a></li>
      <li><a href="<?php echo e(url('/daftar_rombel/tahun_ajaran/'.$data_rombel->tahun_ajar)); ?>">Daftar Rombel</a></li>
      <li class="active">Siswa</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Daftar Siswa Rombel: <b><?php echo e($data_rombel->nama_rombel); ?></b></h3>
            <h5>Wali Kelas: <?php echo e($data_rombel->wali_kelas); ?> </h5>
            <div class="btn-group pull-right">
              <a href="<?php echo e(url('/daftar_rombel/absensi/export_data/'.$id_rombel)); ?>" class="btn btn-success btn-sm"><i class="fa fa-file-excel-o"></i> Export Data</a>
              <button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#modal-default">
                <i class="fa fa-plus"></i> Tambah Siswa
              </button>
            </div>
          </div><!-- /.box-header -->

          <!-- Form modal -->
          <div class="modal fade" id="modal-default">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Daftar Siswa</h4>
                  </div>
                  <div class="modal-body table-responsive">
                    <form action="<?php echo e(url('/tambah_siswa_rombel')); ?>" role="form" method="POST">
                      <?php echo csrf_field(); ?>
                      <table id="example1" class="table table-striped">
                        <thead>
                          <tr>
                            <th>No.</th>
                            <th>No. Induk</th>
                            <th>Nama</th>
                            <th>Nilai Peminatan IPA</th>
                            <th>Nilai Peminatan IPS</th>
                            <th>Nilai Peminatan Bahasa</th>
                            <th>Rekomendasi Peminatan 1</th>
                            <th>Rekomendasi Peminatan 2</th>
                            <th>Rekomendasi Peminatan 3</th>
                            <th>Pilih</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $data_daftar_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($data->no_induk); ?></td>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->nilai_ipa); ?></td>
                            <td><?php echo e($data->nilai_ips); ?></td>
                            <td><?php echo e($data->nilai_bahasa); ?></td>
                            <td><?php echo e($data->rekomendasi_1); ?></td>
                            <td><?php echo e($data->rekomendasi_2); ?></td>
                            <td><?php echo e($data->rekomendasi_3); ?></td>
                            <td>
                              <input type="hidden" name="id_rombel" value="<?php echo e($id_rombel); ?>">
                              <input type="checkbox" name="id[]" value="<?php echo e($data->id); ?>">
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Tutup</button>
                      <button type="submit" value="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                  </form>
                </div>
                <!-- /.modal-content -->
              </div>
              <!-- /.modal-dialog -->
            </div>
            <!-- /.modal -->

            <div class="box-body table-responsive">
              <table id="example2" class="table table-striped">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>No. Induk</th>
                    <th>Nama</th>
                    <th>Nilai Peminatan IPA</th>
                    <th>Nilai Peminatan IPS</th>
                    <th>Nilai Peminatan Bahasa</th>
                    <th>Rekomendasi Peminatan 1</th>
                    <th>Rekomendasi Peminatan 2</th>
                    <th>Rekomendasi Peminatan 3</th>
                    <th>Tools</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i=1; ?>
                  <?php $__currentLoopData = $data_siswa_rombel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($data->no_induk); ?></td>
                    <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->nilai_ipa); ?></td>
                    <td><?php echo e($data->nilai_ips); ?></td>
                    <td><?php echo e($data->nilai_bahasa); ?></td>
                    <td><?php echo e($data->rekomendasi_1); ?></td>
                    <td><?php echo e($data->rekomendasi_2); ?></td>
                    <td><?php echo e($data->rekomendasi_3); ?></td>
                    <td width="150">
                      <div class="btn-group">
                        <a href="<?php echo e(url('/delete_siswa/'.$data->id)); ?>" class="btn btn-default"><i class="fa fa-minus"></i></a>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php
                  if (count($data_siswa_rombel) <= 0) {
                    ?>
                    <tr>
                      <td colspan="10" align="center">Belum Ada Data</td>
                    </tr>
                    <?php
                  }
                  ?>
                </tbody>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('script-js'); ?>
  <!-- DataTables -->
  <script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('page-script'); ?>
  <script>
    $(function () {
      $('#example1').DataTable()
      $('#example2').DataTable({
        'paging'      : true,
        'lengthChange': false,
        'searching'   : false,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
      })
    });

    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
    });
  </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_tim_ppdb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>