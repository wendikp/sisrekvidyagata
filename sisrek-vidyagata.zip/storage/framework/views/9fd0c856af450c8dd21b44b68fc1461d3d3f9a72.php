<?php $__env->startSection('title'); ?>
Halaman Angket Peminatan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper layout-boxed">
  <div class="container">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Angket Peminatan
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Silahkan Isi Angket Peminatan:</h3>
          </div><!-- /.box-header -->
          <div class="box-body table-responsive">
            <form action="<?php echo e(url('/store-angket-peminatan')); ?>" role="form" method="POST">
              <?php echo csrf_field(); ?>
              <table id="example2" class="table table-striped">
                <thead>
                  <tr>
                    <th>Kriteria</th>
                    <th>Nilai</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data_kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($data->kriteria); ?></td>
                    <td>
                      <input type="hidden" name="id_user" value="<?php echo e(AUth::user()->id); ?>">
                      <input type="hidden" name="id_kriteria[] " value="<?php echo e($data->id); ?>">
                      <input type="text" name="nilai[]" required="required">
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <div class="box-footer">
                <button name="submit" value="submit" type="submit" class="btn btn-primary pull-right">Submit</button>
              </div>
            </form>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
  </div>
  <!-- /.container -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_siswa', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>