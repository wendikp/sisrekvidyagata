@extends('layouts/template_admin')

@section('title')
Halaman Tambah Pengguna
@endsection

@section('style')
<!-- bootstrap datepicker -->
<link rel="stylesheet" href="{{ asset('AdminLTE/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css') }}">
@endsection

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Tambah Admin
    </h1>
    <ol class="breadcrumb">
      <li><a href="{{ url('/dashboard-admin') }}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li><a href="{{ url('/daftar_admin') }}">Daftar Admin</a></li>
      <li class="active">Tambah</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Informasi Admin</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
            <form action="{{ url('/insert_admin') }}" role="form" method="POST">
              @csrf
              <table class="table table-responsive table-condensed">
                <tr>
                  <div class="form-group">
                    <td style="border: none; width: 110px;">NIP/NIK</td>
                    <td style="border: none; width: 20px;">:</td>
                    <td style="border: none;"><input type="text" class="form-control" name="no_induk" style="width: 230px;" required="required"></td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">Nama Lengkap</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;"><input type="text" class="form-control" name="nama" style="width: 230px;" required="required"></td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">Email</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;"><input type="email" class="form-control" name="email" style="width: 230px;" required="required"></td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">No. HP</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;">
                      <input type="text" class="form-control" name="no_hp" style="width: 230px;" required="required" data-inputmask='"mask": "9999-9999-9999"' data-mask>
                    </td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">Tanggal Lahir</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;">
                      <div class="input-group date">
                        <div class="input-group-addon">
                          <i class="fa fa-calendar"></i>
                        </div>
                        <input type="text" class="form-control" id="datepicker" name="tgl_lahir" style="width: 192px;" required="required">
                      </div>
                    </td>
                  </div>
                </tr>
                <tr>
                  <div class="form-group">
                    <td style="border: none;">Jenis Kelamin</td>
                    <td style="border: none;">:</td>
                    <td style="border: none;">
                      <select name="jenis_kelamin" class="form-control" style="width: 130px;" required="required">
                       <option value="L">Laki-laki</option>
                       <option value="P">Perempuan</option>
                     </select>
                   </td>
                 </div>
               </tr>
               <tr>
                <td style="border: none;">Alamat</td>
                <td style="border: none;">:</td>
                <td style="border: none;"><textarea class="form-control " name="alamat" rows="3" cols="80" required="required"></textarea></td>
              </tr>
            </table>
          </div><!-- /.box-body -->
          <div class="box-header with-border">
            <h3 class="box-title">Password Akun</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
            <table id="example2" class="table table-responsive table-condensed">
              <tr>
                <div class="form-group">
                  <td style="border: none; width: 110px;">Password</td>
                  <td style="border: none;">:</td>
                  <td style="border: none;"><input id="pw1" type="password" class="form-control" name="password" style="width: 230px;" required="required"></td>
                </div>
              </tr>
              <tr>
                <div class="form-group">
                  <td style="border: none;">Konfirmasi Password</td>
                  <td style="border: none;">:</td>
                  <td style="border: none;"><input id="pw2" type="password" class="form-control" name="password_confirmation" style="width: 230px;" required="required"></td>
                </div>
              </tr>
            </table>
          </div>
          <div class="box-footer">
            <button name="submit" value="submit" type="submit" class="btn btn-primary pull-right">Submit</button>
          </div>
        </form>
      </div><!-- /.box -->
    </div><!-- /.col -->
  </div><!-- /.row -->
</section><!-- /.content -->
</div>
@endsection

@section('script-js')
<!-- bootstrap datepicker -->
<script src="{{ asset('AdminLTE/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
<!-- InputMask -->
<script src="{{ asset('AdminLTE/plugins/input-mask/jquery.inputmask.js') }}"></script>
<script src="{{ asset('AdminLTE/plugins/input-mask/jquery.inputmask.date.extensions.js') }}"></script>
<script src="{{ asset('AdminLTE/plugins/input-mask/jquery.inputmask.extensions.js') }}"></script>
@endsection

@section('page-script')
<script type="text/javascript">
  //Input mask
  $('[data-mask]').inputmask()

  //Date picker
  $('#datepicker').datepicker({
    format: "dd-mm-yyyy",
    autoclose:true
  })

  // Password confirmation
  window.onload = function () {
    document.getElementById("pw1").onchange = validatePassword;
    document.getElementById("pw2").onchange = validatePassword;
  }
  function validatePassword(){
    var pass2=document.getElementById("pw2").value;
    var pass1=document.getElementById("pw1").value;
    if(pass1!=pass2)
      document.getElementById("pw2").setCustomValidity("Passwords Tidak Sama, Coba Lagi");
    else
      document.getElementById("pw2").setCustomValidity('');
  }
</script>
@endsection